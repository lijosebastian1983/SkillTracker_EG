import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';
// import More from 'highcharts/highcharts-more';
// import Tree from 'highcharts/modules/treemap';
// import Highcharts from 'highcharts';
// More(Highcharts);
// Tree(Highcharts);

@Component({
  selector: 'st-tree-map',
  templateUrl: './tree-map.component.html',
  styleUrls: ['./tree-map.component.less']
})
export class TreeMapComponent implements OnInit {
  chartData: Chart;
  constructor() { }

  ngOnInit() {
   // this.chartData = this.getChart();
  }

  getChart(): Chart {
    const chart = new Chart({
      series: [{
        type: 'treemap',

        // layoutAlgorithm: 'stripes',
        data: [{
          name: 'A',
          value: 6
        }, {
          name: 'B',
          value: 6
        }, {
          name: 'C',
          value: 4
        }, {
          name: 'D',
          value: 3
        }, {
          name: 'E',
          value: 2
        }, {
          name: 'F',
          value: 2
        }, {
          name: 'G',
          value: 1
        }]
      }],
    });

    return chart;
  }
}
