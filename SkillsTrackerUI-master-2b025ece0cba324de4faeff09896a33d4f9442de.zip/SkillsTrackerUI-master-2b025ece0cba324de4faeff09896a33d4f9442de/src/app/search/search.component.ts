import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'st-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.less']
})
export class SearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
