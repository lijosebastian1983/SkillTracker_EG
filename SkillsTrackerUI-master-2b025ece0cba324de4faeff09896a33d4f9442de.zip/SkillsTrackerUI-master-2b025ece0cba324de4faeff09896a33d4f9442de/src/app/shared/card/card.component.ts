import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'st-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.less']
})
export class CardComponent implements OnInit {

  @Input() title;
  @Input() description;

  constructor() { }

  ngOnInit() {
  }

}
