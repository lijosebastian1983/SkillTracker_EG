﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillTracker.BusinessEntities
{
    public class GraphModel
    {
        public string SkillName { get; set; }
        public double Percent { get; set; }
        public string Color { get; set; }
    }
}
