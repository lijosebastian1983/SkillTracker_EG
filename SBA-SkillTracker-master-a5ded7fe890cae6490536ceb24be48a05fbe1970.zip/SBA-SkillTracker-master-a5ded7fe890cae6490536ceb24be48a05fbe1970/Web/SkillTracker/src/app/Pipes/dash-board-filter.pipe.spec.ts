import { DashBoardFilterPipe } from './dash-board-filter.pipe';

describe('DashBoardFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DashBoardFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
