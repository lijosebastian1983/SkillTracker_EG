import { Pipe, PipeTransform } from '@angular/core';
import {AssociateModel} from '../Model/AssociateModel'

@Pipe({
  name: 'dashBoardFilter'
})
export class DashBoardFilterPipe implements PipeTransform {

  transform(items: AssociateModel[], filterStringName: string, filterStringAssociateID: string, filterStringEmail: string,
    filterStringMobile: string, filterStringSkill: string){

    if (items && items.length){
        return items.filter(item =>{
            if (filterStringName && item.Name.toLowerCase().indexOf(filterStringName.toLowerCase()) === -1){
                return false;
            }
            if (filterStringAssociateID && item.AssociateID.toLowerCase().indexOf(filterStringAssociateID.toLowerCase()) === -1){
                return false;
            }
            if (filterStringEmail && item.Email.toLowerCase().indexOf(filterStringEmail.toLowerCase()) === -1){
                return false;
            }
            if (filterStringMobile && item.Mobile.toString().toLowerCase().indexOf(filterStringMobile.toLowerCase()) === -1){
              return false;
            }
            if (filterStringSkill && item.SkillSummary.toLowerCase().indexOf(filterStringSkill.toLowerCase()) === -1){
              return false;
            }
            return true;
       })
    }
    else{
        return items;
    }
}

}
