import { SkillFilterPipe } from './skill-filter.pipe';

describe('SkillFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SkillFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
