import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-associate-skill',
  templateUrl: './update-associate-skill.component.html',
  styleUrls: ['./update-associate-skill.component.css']
})
export class UpdateAssociateSkillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
