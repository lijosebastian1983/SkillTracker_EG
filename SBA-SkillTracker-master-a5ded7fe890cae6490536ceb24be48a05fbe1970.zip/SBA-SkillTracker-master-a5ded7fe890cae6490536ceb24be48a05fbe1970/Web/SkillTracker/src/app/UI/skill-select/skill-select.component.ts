import { Component, OnChanges ,Input,Output,EventEmitter} from '@angular/core';
import {AssociateSkillMappingModel} from '../../Model/AssociateSkillMappingModel'
@Component({
  selector: 'app-skill-select',
  templateUrl: './skill-select.component.html',
  styleUrls: ['./skill-select.component.css']
})
export class SkillSelectComponent implements OnChanges {

  @Input() associateSkill:AssociateSkillMappingModel[]
  dynamicHtml:string;
  count:number=0;
   constructor() { }  

  ngOnChanges():void{
    this.dynamicHtml="";
    if(typeof this.associateSkill !== 'undefined' && this.associateSkill.length > 0)
    

    for (let det of this.associateSkill) {  
      if(this.count % 2 === 0  )
        this.dynamicHtml+="<div class='row'>"
      //Population Logic
      this.dynamicHtml+=
      "<div class='col-sm-4'>"+
        "<div class='row'>"+
                "<div class='col-sm-4'>"+det.SkillName+" </div>"+
                "<div class='col-sm-1 start_cont'>0</div>"+
                "<div class='col-sm-6 nopadding' >"+
                    "<div class='slider_cont'>"+
                       "<p-slider  [style]='{'width':'100%'}'  [(ngModel)]='d.SkillRate'  [min]='0' [max]='20'></p-slider>"+
                    "</div>"+  
                "</div>"+
                "<div class='col-sm-1'>20</div>"+
        "</div>"+ 
    "</div> "    
      
      if(this.count % 2 === 0  )
        this.dynamicHtml+="</div>"
      this.count+=1

    }
  }


}
