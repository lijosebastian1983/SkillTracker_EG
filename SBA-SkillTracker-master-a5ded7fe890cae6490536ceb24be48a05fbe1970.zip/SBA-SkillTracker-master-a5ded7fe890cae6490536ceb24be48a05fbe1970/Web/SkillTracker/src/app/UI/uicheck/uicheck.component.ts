import { Component, OnInit } from '@angular/core';
import {DashBoardModel} from '../../Model/DashBoardModel';


@Component({
  selector: 'app-uicheck',
  templateUrl: './uicheck.component.html',
  styleUrls: ['./uicheck.component.css']
})
export class UicheckComponent implements OnInit {

  dashBoardModel:DashBoardModel;
  filterStringName:string;
  filterStringAssociateID:string;
  filterStringEmail:string;
  filterStringMobile:string;
  filterStringSkill:string;

  constructor() { }

  ngOnInit() {
    this.dashBoardModel={
        "GraphDetails": [
            {
                "SkillName": "DotNets",
                "Percent": 21.052631578947366,
                "Color": "Blue"
            },
            {
                "SkillName": "Java",
                "Percent": 21.052631578947366,
                "Color": "Green"
            },
            {
                "SkillName": "Angular",
                "Percent": 21.052631578947366,
                "Color": "Yellow"
            },
            {
                "SkillName": "TypeScript",
                "Percent": 21.052631578947366,
                "Color": "Cyan"
            },
            {
                "SkillName": "JavaScript",
                "Percent": 15.789473684210526,
                "Color": "white"
            }
        ],
        "RegistredCandidate": 4,
        "FemaleCandidate": 25,
        "MaleCandidate": 75,
        "FresherCandidate": 0,
        "RatedCandidate": 4,
        "FemaleRatedCandidate": 0,
        "MaleRatedCandidate": 0,
        "Level1Candidate": 0,
        "Level2Candidate": 0,
        "Level3Candidate": 0,
        "AssociateDetails": [
            {
                "AssociateDetailsID": 6,
                "AssociateID": "357672",
                "Name": "Sandeep Kurup",
                "Email": "dsasd.da.com",
                "Mobile": 0,
                "Sex": null,
                "Pic": "Test",
                "StatusGreen": false,
                "StatusBlue": false,
                "StatusRed": false,
                "Level1": false,
                "Level2": false,
                "Level3": false,
                "Remark": null,
                "Other": null,
                "Strength": null,
                "Weakness": null,
                "SkillSummary": "DotNets, Java, Angular, TypeScript",
                "StatusColor": "Red"
            },
            {
                "AssociateDetailsID": 1005,
                "AssociateID": "534",
                "Name": "raj",
                "Email": "gdfgfdg",
                "Mobile": 0,
                "Sex": null,
                "Pic": "rwerwe",
                "StatusGreen": false,
                "StatusBlue": false,
                "StatusRed": false,
                "Level1": false,
                "Level2": false,
                "Level3": false,
                "Remark": null,
                "Other": null,
                "Strength": null,
                "Weakness": null,
                "SkillSummary": "DotNets, Java, Angular, TypeScript, JavaScript",
                "StatusColor": "Red"
            },
            {
                "AssociateDetailsID": 1006,
                "AssociateID": "534",
                "Name": "sura",
                "Email": "gdfgfdg",
                "Mobile": 0,
                "Sex": null,
                "Pic": "rwerwe",
                "StatusGreen": false,
                "StatusBlue": false,
                "StatusRed": false,
                "Level1": false,
                "Level2": false,
                "Level3": false,
                "Remark": null,
                "Other": null,
                "Strength": null,
                "Weakness": null,
                "SkillSummary": "DotNets, Java, Angular, TypeScript, JavaScript",
                "StatusColor": "Red"
            },
            {
                "AssociateDetailsID": 1007,
                "AssociateID": "534",
                "Name": "deepi",
                "Email": "gdfgfdg",
                "Mobile": 0,
                "Sex": null,
                "Pic": "rwerwe",
                "StatusGreen": false,
                "StatusBlue": false,
                "StatusRed": false,
                "Level1": false,
                "Level2": false,
                "Level3": false,
                "Remark": null,
                "Other": null,
                "Strength": null,
                "Weakness": null,
                "SkillSummary": "DotNets, Java, Angular, TypeScript, JavaScript",
                "StatusColor": "Red"
            }
        ]
    }
  }

}
