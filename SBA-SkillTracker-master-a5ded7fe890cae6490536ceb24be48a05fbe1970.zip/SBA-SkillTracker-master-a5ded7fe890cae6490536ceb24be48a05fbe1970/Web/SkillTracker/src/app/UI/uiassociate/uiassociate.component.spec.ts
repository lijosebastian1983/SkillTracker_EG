import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UiassociateComponent } from './uiassociate.component';

describe('UiassociateComponent', () => {
  let component: UiassociateComponent;
  let fixture: ComponentFixture<UiassociateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UiassociateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UiassociateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
