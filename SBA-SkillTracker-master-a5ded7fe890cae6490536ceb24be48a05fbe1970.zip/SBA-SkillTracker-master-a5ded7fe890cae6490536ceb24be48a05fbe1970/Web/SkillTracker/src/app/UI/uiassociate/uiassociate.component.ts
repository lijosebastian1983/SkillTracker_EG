import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AssociateSkillsModel} from '../../Model/AssociateSkillsModel'
import {AssociateServiceService} from '../../Services/associate-service.service'
import { FormGroup, FormBuilder, Validators , ReactiveFormsModule} from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService} from 'primeng/api';
import {SliderModule} from 'primeng/slider';


@Component({
  selector: 'app-uiassociate',
  templateUrl: './uiassociate.component.html',
  styleUrls: ['./uiassociate.component.css']
})
export class UiassociateComponent implements OnInit {

  form: FormGroup;
  associateSkill:AssociateSkillsModel;
  errorMessage: string;
  genders:string[] = ['Male','Female'];

  messageDisplay :string=''
  messageType:string=''

  constructor(private _associateservice: AssociateServiceService, private _router: Router,private formBuilder: FormBuilder,
    private confirmationService: ConfirmationService) { }

    ngOnInit() {
      this.form = this.formBuilder.group({
        skillz: [null,Validators.required]        
      });
     
      this.ResetPage();
    }
    ResetPage()
    {
      this.associateSkill={
        "AssociateDetails": {
            "AssociateDetailsID": 0,
            "AssociateID": "",
            "Name": "",
            "Email": "",
            "Mobile": 0,
            "Sex": "Male",
            "Pic": "",
            "StatusGreen": false,
            "StatusBlue": false,
            "StatusRed": false,
            "Level1": false,
            "Level2": false,
            "Level3": false,
            "Remark": "",
            "Other": "",
            "Strength": "",
            "Weakness": "",
            "SkillSummary": null,
            "StatusColor": null
        },
        "Skills": [
            {
                "AssociateSkillID": 0,
                "AssociateDetailsID": 0,
                "SkillId": 1,
                "SkillName": "DotNets",
                "SkillRate": 0
            },
            {
                "AssociateSkillID": 0,
                "AssociateDetailsID": 0,
                "SkillId": 2,
                "SkillName": "Java",
                "SkillRate": 0
            },
            {
                "AssociateSkillID": 0,
                "AssociateDetailsID": 0,
                "SkillId": 3,
                "SkillName": "Angular",
                "SkillRate": 0
            },
            {
                "AssociateSkillID": 0,
                "AssociateDetailsID": 0,
                "SkillId": 4,
                "SkillName": "TypeScript",
                "SkillRate": 0
            },
            {
                "AssociateSkillID": 0,
                "AssociateDetailsID": 0,
                "SkillId": 5,
                "SkillName": "JavaScript",
                "SkillRate": 0
            }
        ]
    }  
    }

}
