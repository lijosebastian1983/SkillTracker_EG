 
export class AssociateModel{
    AssociateDetailsID: number;
    AssociateID: string;
    Name:string;
    Email:string;
    Mobile:number;
    Sex:string;
    Pic:string;
    StatusGreen:boolean;
    StatusBlue:boolean;
    StatusRed:boolean;
    Level1:boolean;
    Level2:boolean;
    Level3:boolean;
    Remark:string;
    Other:string;
    Strength:string;
    Weakness:string;
    SkillSummary:string;
    StatusColor:string;
    constructor(associate_details_id:number,associate_id:string,name:string ,email:string ,mobile:number
        ,sex:string,pic:string,status_green:boolean,status_blue:boolean
        ,status_red:boolean,level1:boolean,level2:boolean,level3:boolean
        ,remark:string,other:string,strength:string,weakness:string,skillSummary:string,statusColor:string)

    {
        this.AssociateDetailsID=associate_details_id,
        this.AssociateID=associate_id;
        this.Name=name
        this.Email=email;
        this.Mobile=mobile
        this.Sex=sex;
        this.Pic=pic
        this.StatusGreen=status_green;
        this.StatusBlue=status_blue
        this.StatusRed=status_red;
        this.Level1=level1
        this.Level2=level2;
        this.Level3=level3
        this.Remark=remark;
        this.Other=other;
        this.Strength=strength;
        this.Weakness=weakness;
        this.SkillSummary=skillSummary;
        this.StatusColor=statusColor;
    }
}