export class GraphModel{
    SkillName:string;
    Percent:number;
    Color:string;
    constructor(skillName:string,percent:number,color:string){
        this.SkillName=skillName;
        this.Percent=percent;
        this.Color=color;
    }
}