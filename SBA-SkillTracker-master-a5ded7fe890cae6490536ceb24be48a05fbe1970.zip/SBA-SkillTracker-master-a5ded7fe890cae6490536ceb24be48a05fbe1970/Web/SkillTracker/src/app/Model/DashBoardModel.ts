import {AssociateModel} from './AssociateModel'
import {GraphModel} from './GraphModel'
export class DashBoardModel{
    GraphDetails:GraphModel[];
    RegistredCandidate:number;
    FemaleCandidate:number;
    MaleCandidate:number;
    FresherCandidate:number;
    RatedCandidate:number;
    FemaleRatedCandidate:number;
    MaleRatedCandidate:number;
    Level1Candidate:number;
    Level2Candidate:number;
    Level3Candidate:number;
    AssociateDetails:AssociateModel[];
    constructor(graphDetails:GraphModel[],registredCandidate:number,femaleCandidate:number,maleCandidate:number,
        fresherCandidate:number,ratedCandidate:number,femaleRatedCandidate:number,maleRatedCandidate:number,
        level1Candidate:number,level2Candidate:number,level3Candidate:number,associateDetails:AssociateModel[] )
    {
        this.GraphDetails=graphDetails;
        this.RegistredCandidate=registredCandidate;
        this.FemaleCandidate=femaleCandidate;
        this.MaleCandidate=maleCandidate;
        this.FresherCandidate=fresherCandidate;
        this.RatedCandidate=ratedCandidate;
        this.FemaleRatedCandidate=femaleRatedCandidate;
        this.MaleRatedCandidate=maleRatedCandidate;
        this.Level1Candidate=level1Candidate;
        this.Level2Candidate=level2Candidate;        
        this.Level3Candidate=level3Candidate;  
        this.AssociateDetails=associateDetails;  
    }
}