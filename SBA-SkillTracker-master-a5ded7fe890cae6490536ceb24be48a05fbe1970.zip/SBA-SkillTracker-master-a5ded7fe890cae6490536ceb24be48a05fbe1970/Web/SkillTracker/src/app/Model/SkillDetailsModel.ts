export class SkillDetailsModel{
    SkillId: number;
    SkillName:string;
    constructor(skill_id:number,skill_name:string)
    {
        this.SkillId=skill_id;
        this.SkillName=skill_name
    }
}