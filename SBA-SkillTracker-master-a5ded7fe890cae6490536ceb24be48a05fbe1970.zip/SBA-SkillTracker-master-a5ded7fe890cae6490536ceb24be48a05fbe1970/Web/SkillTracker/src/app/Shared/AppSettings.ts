export class AppSettings {
    //Local URL
    //  public static API_ENDPOINT='http://localhost:49512/api/';
   //Hoseted URL
    public static API_ENDPOINT='http://localhost:50851/api/';
 }