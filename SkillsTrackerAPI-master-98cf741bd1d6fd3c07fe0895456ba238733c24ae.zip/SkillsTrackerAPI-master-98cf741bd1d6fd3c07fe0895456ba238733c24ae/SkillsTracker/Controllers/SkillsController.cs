﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using SkillsTracker.Core;
using SkillsTracker.DataAccess;

namespace SkillsTracker.Controllers
{
    [RoutePrefix("api/skills")]
    public class SkillsController : ApiController
    {
        private readonly ISkillsRepository repo;

        public SkillsController(ISkillsRepository repo)
        {
            this.repo = repo;
        }

        [HttpGet]
        [Route("")]
        public List<Skill> GetSkills()
        {
            return repo.GetSkills();
        }

        [HttpGet]
        [ResponseType(typeof(Skill))]
        [Route("{id:int}")]
        public IHttpActionResult GetSkills(int id)
        {
            Skill skill = repo.GetSkill(id);
            if (skill == null)
            {
                return NotFound();
            }
            return Ok(skill);
        }

        [HttpPut]
        [ResponseType(typeof(void))]
        [Route("{id:int}/update")]
        public IHttpActionResult UpdateSkill(int id, Skill skill)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != skill.ID)
            {
                return BadRequest();
            }

            try
            {
                repo.UpdateSkill(skill);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpPost]
        [ResponseType(typeof(Skill))]
        [Route("insert", Name = "PostSkills")]
        public IHttpActionResult PostSkills(Skill skill)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            repo.AddSkill(skill);

            return CreatedAtRoute("PostSkills", new { id = skill.ID }, skill);
        }

        [HttpDelete]
        [ResponseType(typeof(Skill))]
        [Route("{id:int}/delete")]
        public IHttpActionResult DeleteSkills(int id)
        {
            Skill skills = repo.DeleteSkill(id);

            if (skills == null)
            {
                return NotFound();
            }

            return Ok(skills);
        }


    }
}