namespace SkillsTracker.DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Associates",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Email = c.String(),
                        Gender = c.Int(nullable: false),
                        Mobile = c.String(),
                        Pic = c.String(),
                        Status = c.Int(nullable: false),
                        Level = c.Int(nullable: false),
                        Remark = c.String(),
                        Strength = c.String(),
                        Weakness = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Skills",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.SkillAssociates",
                c => new
                    {
                        Skill_ID = c.Int(nullable: false),
                        Associate_ID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Skill_ID, t.Associate_ID })
                .ForeignKey("dbo.Skills", t => t.Skill_ID, cascadeDelete: true)
                .ForeignKey("dbo.Associates", t => t.Associate_ID, cascadeDelete: true)
                .Index(t => t.Skill_ID)
                .Index(t => t.Associate_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.SkillAssociates", "Associate_ID", "dbo.Associates");
            DropForeignKey("dbo.SkillAssociates", "Skill_ID", "dbo.Skills");
            DropIndex("dbo.SkillAssociates", new[] { "Associate_ID" });
            DropIndex("dbo.SkillAssociates", new[] { "Skill_ID" });
            DropTable("dbo.SkillAssociates");
            DropTable("dbo.Skills");
            DropTable("dbo.Associates");
        }
    }
}
