﻿using SkillsTracker.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsTracker.DataAccess
{
    public interface ISkillsRepository
    {
        List<Skill> GetSkills();
        Skill GetSkill(int id);
        Skill AddSkill(Skill skill);
        void UpdateSkill(Skill skill);
        Skill DeleteSkill(int id);
    }

}
