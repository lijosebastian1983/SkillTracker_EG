﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SkillsTracker.Core;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace SkillsTracker.DataAccess
{
    public class SkillsRepository : ISkillsRepository
    {
        private readonly SkillsTrackerContext db;
        public SkillsRepository(SkillsTrackerContext db)
        {
            this.db = db;
        }

        public Skill AddSkill(Skill skill)
        {
            db.Skills.Add(skill);
            db.SaveChanges();

            return skill;
        }

        public Skill DeleteSkill(int id)
        {
            Skill skill = db.Skills.Find(id);
            if (skill == null)
            {
                return null;
            }

            db.Skills.Remove(skill);
            db.SaveChanges();

            return skill;
        }

        public Skill GetSkill(int id)
        {
            Skill skills = db.Skills.Find(id);
            return skills;
        }

        public List<Skill> GetSkills()
        {
            return db.Skills.ToList();
        }

        public void UpdateSkill(Skill skill)
        {
            db.Entry(skill).State = EntityState.Modified;
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
        }





        private bool SkillsExists(int id)
        {
            return db.Skills.Count(e => e.ID == id) > 0;
        }
    }
}
