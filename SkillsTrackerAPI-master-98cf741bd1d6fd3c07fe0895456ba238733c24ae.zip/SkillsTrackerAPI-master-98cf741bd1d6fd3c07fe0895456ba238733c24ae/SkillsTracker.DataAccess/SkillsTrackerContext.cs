﻿using SkillsTracker.Core;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace SkillsTracker.DataAccess
{
    public class SkillsTrackerContext : DbContext
    {
        public SkillsTrackerContext() : base("conn")
        {
            this.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
        }

        public DbSet<Skill> Skills { get; set; }
        public DbSet<Associate> Associates { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
