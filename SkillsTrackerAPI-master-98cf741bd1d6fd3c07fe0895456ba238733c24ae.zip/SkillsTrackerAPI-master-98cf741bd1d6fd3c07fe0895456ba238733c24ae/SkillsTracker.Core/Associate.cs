﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsTracker.Core
{
    public class Associate
    {
        public Associate()
        {
            Skills = new List<Skill>();
        }

        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public Gender Gender { get; set; }
        public string Mobile { get; set; }
        public string Pic { get; set; }
        public Status Status { get; set; }
        public Level Level { get; set; }
        public string Remark { get; set; }
        public string Strength { get; set; }
        public string Weakness { get; set; }

        public ICollection<Skill> Skills { get; set; }

    }
}
