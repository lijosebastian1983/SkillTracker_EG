﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsTracker.Core
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }

    public enum Status
    {
        Green = 1,
        Blue = 2,
        Red = 3
    }

    public enum Level
    {
        Level1 = 1,
        Level2 = 2,
        Level3 = 3
    }

}
